﻿import { Component } from '@angular/core';

@Component({ templateUrl: 'layout-song.component.html' })
export class LayoutSongComponent { }