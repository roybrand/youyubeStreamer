﻿export class User {
    id: string;
    password: string;
    firstName: string;
    lastName: string;
    email: string;
    token: string;
}